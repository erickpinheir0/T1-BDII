-------------------------------------------------------------------------------
-- VALIDAR CARGA DE DADOS
-------------------------------------------------------------------------------
-- TABELA: LIV_CLIENTES        = 50
-- TABELA: LIV_ENDERECOS       = 75
-- TABELA: LIV_EDITORAS        = 25
-- TABELA: LIV_AUTORES         = 221
-- TABELA: LIV_LIVROS          = 318
-- TABELA: LIV_LIVRO_AUTOR     = 318
-- TABELA: LIV_CATEGORIAS      = 113
-- TABELA: LIV_LIVRO_CATEGORIA = 318
-- TABELA: LIV_PEDIDOS         = 350
-- TABELA: LIV_PEDIDO_ITENS    = 1564
-- TABELA: LIV_PAGAMENTOS      = 350
-- TABELA: LIV_ESTOQUE         = 318
-------------------------------------------------------------------------------

select (select count(1) from LIV_CLIENTES)        as t_LIV_CLIENTES,
       (select count(1) from LIV_ENDERECOS)       as t_LIV_ENDERECOS,
       (select count(1) from LIV_EDITORAS)        as t_LIV_EDITORAS,
       (select count(1) from LIV_AUTORES)         as t_LIV_AUTORES,
       (select count(1) from LIV_LIVROS)          as t_LIV_LIVROS,
       (select count(1) from LIV_LIVRO_AUTOR)     as t_LIV_LIVRO_AUTOR,
       (select count(1) from LIV_CATEGORIAS)      as t_LIV_CATEGORIAS,
       (select count(1) from LIV_LIVRO_CATEGORIA) as t_LIV_LIVRO_CATEGORIA,
       (select count(1) from LIV_PEDIDOS)         as t_LIV_PEDIDOS,
       (select count(1) from LIV_PEDIDO_ITENS)    as t_LIV_PEDIDO_ITENS,
       (select count(1) from LIV_PAGAMENTOS)      as t_LIV_PAGAMENTOS,
       (select count(1) from LIV_ESTOQUE)         as t_LIV_ESTOQUE
  from dual;
