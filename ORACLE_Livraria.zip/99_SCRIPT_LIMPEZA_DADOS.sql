-------------------------------------------------------------------------------
-- EXCLUIR TABELAS
-------------------------------------------------------------------------------
DROP TABLE LIV_ESTOQUE;
DROP TABLE LIV_PAGAMENTOS;
DROP TABLE LIV_PEDIDO_ITENS;
DROP TABLE LIV_PEDIDOS;
DROP TABLE LIV_LIVRO_CATEGORIA;
DROP TABLE LIV_CATEGORIAS;
DROP TABLE LIV_LIVRO_AUTOR;
DROP TABLE LIV_LIVROS;
DROP TABLE LIV_AUTORES;
DROP TABLE LIV_EDITORAS;
DROP TABLE LIV_CLIENTES CASCADE CONSTRAINTS;
DROP TABLE LIV_ENDERECOS CASCADE CONSTRAINTS;

-------------------------------------------------------------------------------
-- EXCLUIR INDICES
-------------------------------------------------------------------------------
SELECT 'DROP INDEX ' || i.owner || '.' || i.index_name || ';' AS ddl
FROM   ALL_INDEXES i
JOIN   ALL_OBJECTS o
  ON   o.owner = i.owner
 AND   o.object_name = i.table_name
WHERE  i.owner = 'AULA'
  AND  o.object_type = 'TABLE'
  AND  o.object_name LIKE 'LIV_%'
  AND  NOT EXISTS (  -- não derrubar PK/UK
        SELECT 1
        FROM   ALL_CONSTRAINTS c
        WHERE  c.owner = i.owner
          AND  c.index_name = i.index_name
          AND  c.constraint_type IN ('P','U')
      )
ORDER BY 1;